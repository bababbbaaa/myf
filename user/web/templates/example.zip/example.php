<?php 

	$lead_data = [
        #обязательные
        'type' => 'dolgi', # тип лидов, можно найти в оффере
        'phone' => '8(909)-012-33-34',
        'ip' => $_SERVER['REMOTE_ADDR'], # либо указать регион
        'region' => 'Московская обл', # либо указать IP
        'provider_token' => '< ключ поставщика >', # ваш ключ поставщика
        'offer_token' => '< ключ оффера >', # ключ оффера можно найти в его карточке

        #необязательные
        'name' => 'Вася',
        'email' => 'pupkin.ceo@gmail.co.uk',
        'city' => 'Домодедово',
        'comments' => 'Комментарий 1<br>Комментарий 2',
        'params' => json_encode(['sum' => 1500000, 'sum_text' => 'от 500 000 рублей'],
            JSON_UNESCAPED_UNICODE), # параметры лидов можно узнать в оффере
        'utm_source' => 'some_utm',
        'utm_campaign' => 'some_utm',
        'utm_medium' => 'some_utm',
        'utm_content' => 'some_utm',
        'utm_term' => 'some_utm',
        'utm_title' => 'some_utm',
        'utm_device_type' => 'some_utm',
        'utm_age' => 'some_utm',
        'utm_inst' => 'some_utm',
        'utm_special' => 'some_utm'
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://api.myforce.ru/lead.add',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($lead_data),
        CURLOPT_TIMEOUT => 10,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_RETURNTRANSFER => true
    ]);

    $response = curl_exec($ch);
    if (!$response)
        $response = ['type' => 'error', 'code' => 'curl', 'message' => curl_error($ch)];
    curl_close($ch);

 ?>